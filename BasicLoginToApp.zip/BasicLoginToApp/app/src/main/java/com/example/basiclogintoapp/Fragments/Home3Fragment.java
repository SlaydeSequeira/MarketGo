package com.example.basiclogintoapp.Fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.basiclogintoapp.R;
import com.example.basiclogintoapp.adapter.ItemAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
import java.util.HashMap;
public class Home3Fragment extends Fragment {
    DatabaseReference itemsReference;
    String title[] = new String[100];
    private String[] imgUrls = new String[100];
    private String[] cpValues = new String[100];
    private String[] spValues = new String[100];
    private String[] aisleValues = new String[100];
    private String[] categoryValues = new String[100];
    private String[] quantityValues = new String[100];
    private String[] reviewValues = new String[100];
    int itemCount = 0; // Counter for the number of items

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home3, container, false);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        itemsReference = database.getReference("items");

        itemsReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Clear arrays before populating them
                    clearArrays();

                    // Iterate through all children of the "items" node
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        // Access the key of each child
                        String itemKey = childSnapshot.getKey();
                        String img = childSnapshot.child("img").getValue(String.class);
                        Long aisleNumberLong = childSnapshot.child("aisle").getValue(Long.class);
                        String a = String.valueOf(aisleNumberLong);
                        aisleValues[itemCount] = a;
                        imgUrls[itemCount] = String.valueOf(img);
                        title[itemCount] = itemKey;

                        // Increment the counter
                        itemCount++;
                    }

                    // After updating the data, update the RecyclerView adapter
                    updateRecyclerView();
                } else {
                    // Handle the case where the "items" node is empty
                    Log.d("NoData", "No data found in 'items' node");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database error
                Log.e("DatabaseError", "Error fetching data: " + error.getMessage());
            }
        });

        RecyclerView recyclerView;
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Initialize the adapter with empty data arrays
        ItemAdapter adapter = new ItemAdapter(itemCount, title, imgUrls, cpValues, aisleValues, aisleValues, title, title, title);

        // Set the adapter to the recyclerView
        recyclerView.setAdapter(adapter);
        return view;
    }

    private void clearArrays() {
        // Clear arrays before populating them with new data
        Arrays.fill(title, null);
        Arrays.fill(imgUrls, null);
        Arrays.fill(cpValues, null);
        Arrays.fill(spValues, null);
        Arrays.fill(aisleValues, null);
        Arrays.fill(categoryValues, null);
        Arrays.fill(quantityValues, null);
        Arrays.fill(reviewValues, null);

        // Reset the itemCount counter
        itemCount = 0;
    }

    private void updateRecyclerView() {
        // Update the RecyclerView adapter with the new data
        ItemAdapter adapter = new ItemAdapter(itemCount, title, imgUrls, cpValues, aisleValues, aisleValues, title, title, title);
        RecyclerView recyclerView = getView().findViewById(R.id.recyclerView);
        recyclerView.setAdapter(adapter);
    }
}
