package com.example.basiclogintoapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.basiclogintoapp.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import java.util.Map;
// ItemAdapter.java
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    int count;
    private int toastCounter = 0;
    private String[] itemNames = new String[100];
    private String[] imgUrls = new String[100];
    private String[] cpValues = new String[100];
    private String[] spValues = new String[100];
    private String[] aisleValues = new String[100];
    private String[] categoryValues = new String[100];
    private String[] quantityValues = new String[100];
    private String[] reviewValues = new String[100];

    public ItemAdapter(int count,String[] itemNames, String[] imgUrls, String[] cpValues, String[] spValues,
                       String[] aisleValues, String[] categoryValues, String[] quantityValues, String[] reviewValues) {
        this.count = count;
        this.itemNames = itemNames;
        this.imgUrls = imgUrls;
        this.cpValues = cpValues;
        this.spValues = spValues;
        this.aisleValues = aisleValues;
        this.categoryValues = categoryValues;
        this.quantityValues = quantityValues;
        this.reviewValues = reviewValues;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.add, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.textView.setText(itemNames[position]);
        holder.textView2.setText("Aisle Location: "+aisleValues[position]);
        Glide.with(holder.itemView.getContext())
                .load(imgUrls[position])
                .placeholder(R.drawable.back)
                .error(R.drawable.back)
                .into(holder.imageView);

        // Add your item click handling here
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle item click
            }
        });
    }

    @Override
    public int getItemCount() {
        return count;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        TextView textView2;
        ImageView imageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.text);
            textView2 = itemView.findViewById(R.id.text2);
            imageView = itemView.findViewById(R.id.imageinrecycler);

            // Add other view bindings as needed
        }
    }
}
